document.addEventListener('DOMContentLoaded', function() {
    function fetchResources(endpoint, sectionId) {
        fetch(endpoint)
            .then(response => response.json())
            .then(resources => {
                const section = document.getElementById(sectionId);
                section.innerHTML = ''; // Clear existing resources
                resources.forEach(resource => {
                    const resourceItem = document.createElement('div');
                    resourceItem.classList.add('resource-item');
                    resourceItem.innerHTML = `
                        <h3>${resource.title}</h3>
                        <p class="rating">Rating: ${resource.rating}</p>
                    `;
                    section.appendChild(resourceItem);
                });
            })
            .catch(error => console.error('Error fetching resources:', error));
    }

    function addResource(event) {
        event.preventDefault();
        const title = document.getElementById('title').value;
        const rating = document.getElementById('rating').value;
        const type = document.getElementById('type').value;

        fetch('/api/resources', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, rating, type })
        })
        .then(response => response.json())
        .then(data => {
            // Fetch and display updated resources
            fetchResources('/api/exam-prep-resources', 'exam-prep-list');
            fetchResources('/api/open-edu-resources', 'open-edu-list');
        })
        .catch(error => console.error('Error adding resource:', error));
    }

    document.getElementById('add-resource-form').addEventListener('submit', addResource);

    fetchResources('/api/exam-prep-resources', 'exam-prep-list');
    fetchResources('/api/open-edu-resources', 'open-edu-list');
});
