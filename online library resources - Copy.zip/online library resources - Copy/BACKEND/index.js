const express = require('express');
const bodyParser = require('body-parser');
const Sequelize = require('sequelize');
const jwt = require('jsonwebtoken');

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: './database.sqlite'
});

const Resource = sequelize.define('Resource', {
    title: {
        type: Sequelize.STRING,
        allowNull: false
    },
    rating: {
        type: Sequelize.FLOAT,
        allowNull: false
    },
    type: {
        type: Sequelize.STRING,
        allowNull: false
    }
});

const User = sequelize.define('User', {
    username: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: Sequelize.STRING,
        allowNull: false
    }
});

const app = express();
app.use(bodyParser.json());

const secretKey = 'your_secret_key';

app.post('/api/register', async (req, res) => {
    try {
        const { username, password } = req.body;
        const newUser = await User.create({ username, password });
        res.json(newUser);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ where: { username, password } });
        if (user) {
            const token = jwt.sign({ id: user.id, username: user.username }, secretKey);
            res.json({ token });
        } else {
            res.status(401).json({ error: 'Invalid credentials' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/exam-prep-resources', async (req, res) => {
    const resources = await Resource.findAll({ where: { type: 'exam-prep' } });
    res.json(resources);
});

app.get('/api/open-edu-resources', async (req, res) => {
    const resources = await Resource.findAll({ where: { type: 'open-edu' } });
    res.json(resources);
});

app.post('/api/resources', async (req, res) => {
    try {
        const token = req.headers.authorization.split(' ')[1];
        jwt.verify(token, secretKey);
        const { title, rating, type } = req.body;
        const newResource = await Resource.create({ title, rating, type });
        res.json(newResource);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

async function addDummyData() {
    const resources = [
        { title: 'Math Exam Prep', rating: 4.5, type: 'exam-prep' },
        { title: 'Physics Exam Prep', rating: 4.7, type: 'exam-prep' },
        { title: 'Chemistry Exam Prep', rating: 4.3, type: 'exam-prep' },
        { title: 'Open Course in Computer Science', rating: 4.8, type: 'open-edu' },
        { title: 'Open Course in Psychology', rating: 4.6, type: 'open-edu' },
        { title: 'Open Course in Literature', rating: 4.4, type: 'open-edu' }
    ];
    await Resource.bulkCreate(resources);
}

sequelize.sync({ force: true }).then(async () => {
    await addDummyData();
    app.listen(3000, () => {
        console.log('Server is running on http://localhost:3000');
    });
}).catch(error => {
    console.error('Unable to connect to the database:', error);
});
